import io
import docx
import fitz
import json
import base64
import chardet
import pdfplumber
import pandas as pd
from PIL import Image
from flask import current_app
import tiktoken


class FileOperation:

    @staticmethod
    def extract_images_from_pdf(pdf_path, is_content):
        if not is_content:
            return []
        with fitz.open(stream=pdf_path) as doc:
            base64_img = []
            for page_index in range(len(doc)):
                if page_index not in is_content:
                    continue
                # if img:= doc[page_index].get_images(full=True):
                #     xref = img[-1][0]
                #     base_image = doc.extract_image(xref)
                #     image_bytes = base_image["image"]
                #     img = Image.open(io.BytesIO(image_bytes))
                #     buffered = io.BytesIO()
                #     img.save(buffered, format="PNG")
                #     img = base64.b64encode(buffered.getvalue()).decode()
                #     base64_img.append(img)
                # else:
                page = doc[page_index]
                pix = page.get_pixmap(dpi=500)
                img = Image.open(io.BytesIO(pix.tobytes("png")))
                buffered = io.BytesIO()
                img.save(buffered, format="PNG")
                img = base64.b64encode(buffered.getvalue()).decode()
                base64_img.append(img)
        return base64_img

    @staticmethod
    def extract_text_from_pdf(pdf_path):
        pdf_bytes = io.BytesIO(pdf_path)
        is_content = []
        final_text = []
        tables = []
        df = ""
        with pdfplumber.open(pdf_bytes) as pdf:
            for page in pdf.pages:
                table = page.extract_table()
                if table and any(any(once) for once in table):
                    tables.append(table)
                    table_bboxes = [pos.bbox for pos in page.find_tables()]
                    filtered_text = page.extract_words()
                    for word in filtered_text:
                        x0, y0, x1, y1 = word["x0"], word["top"], word["x1"], word["bottom"]
                        inside_table = any(
                            t_x0 <= x0 <= t_x1 and t_y0 <= y0 <= t_y1
                            for (t_x0, t_y0, t_x1, t_y1) in table_bboxes
                        )
                        if not inside_table:
                            final_text.append(word["text"])
                else:
                    text = page.extract_text()
                    if text and len(text) > 10:
                        final_text.append(text)
                    else:
                        is_content.append(page.page_number - 1)
            if tables:
                try:
                    df = "\n".join(pd.DataFrame(table[1:], columns=table[0]).to_json(
                        force_ascii=False) for table in tables)
                except:
                    df = json.dumps(tables)
            if final_text:
                final_text = " ".join(final_text) + "\n"
            else:
                final_text = ""
        return final_text + df, is_content

    @staticmethod
    def extract_text_from_word(docx_path):
        doc = docx.Document(docx_path)
        text = "\n".join([p.text for p in doc.paragraphs])
        tables = []
        df = ""

        for table in doc.tables:
            table_data = []
            for row in table.rows:
                row_data = [cell.text.strip() for cell in row.cells]
                table_data.append(row_data)
            if table_data:
                tables.append(table_data)
        if tables:
            try:
                df = pd.DataFrame(tables[0][1:], columns=tables[0][0]).to_json(
                    force_ascii=False)
            except:
                df = json.dumps(tables, ensure_ascii=False)
        return text.strip() + df

    @staticmethod
    def extract_images_from_word(docx_path):
        doc = docx.Document(docx_path)
        base64_img = []
        for rel in doc.part.rels:
            if "image" in doc.part.rels[rel].target_ref:
                image = doc.part.rels[rel].target_part.blob
                img = Image.open(io.BytesIO(image))
                buffered = io.BytesIO()
                img.save(buffered, format="PNG")
                base64.b64encode(buffered.getvalue()).decode()
                base64_img.append(img)
        return base64_img

    @staticmethod
    def check_pdf(pdf_path):
        with fitz.open(stream=pdf_path) as doc:
            for page_index in range(len(doc)):
                if doc[page_index].get_images(full=True) or not doc[page_index].get_text("text"):
                    page = doc[page_index]
                    pix = page.get_pixmap(dpi=500)
                    rect = page.rect
                    page.clean_contents()
                    page.insert_image(rect, pixmap=pix)
            pdf_buffer = io.BytesIO()
            doc.save(pdf_buffer, garbage=4, deflate=True)
            pdf_byte_path = pdf_buffer.getvalue()
        return pdf_byte_path

    @staticmethod
    def extract_picture(picture_path):
        base64_img = []
        img = Image.open(picture_path)
        buffered = io.BytesIO()
        img.save(buffered, format="PNG")
        img = base64.b64encode(buffered.getvalue()).decode()
        base64_img.append(img)
        return base64_img

    def __call__(self, username: str, attachment_name: str):
        file_extension = attachment_name.rsplit(".", 1)[1]
        file_extension = file_extension.lower()
        # blob_client = current_app.container_client.get_blob_client(f"{username}/{attachment_name}")
        stream = blob_client.download_blob().readall()
        file_stream = io.BytesIO(stream)
        encoding = chardet.detect(stream)["encoding"]

        if file_extension == "txt":
            txt_content = stream.decode(encoding)
            return [txt_content, []]
        elif file_extension == "csv":
            df = pd.read_csv(file_stream, encoding=encoding)
            return [df.to_json(force_ascii=False), []]
        elif file_extension == "json":
            json_content = stream.decode(encoding)
            return [json_content, []]
        elif file_extension in ["xlsx", "xls"]:
            df = pd.read_excel(file_stream, engine="openpyxl")
            return [df.to_json(force_ascii=False), []]
        elif file_extension == "pdf":
            # stream_result = self.check_pdf(stream)
            pdf_text, page_num = self.extract_text_from_pdf(stream)
            pdf_images = self.extract_images_from_pdf(stream, page_num)
            return [pdf_text, pdf_images]
        elif file_extension == "docx":
            word_text = self.extract_text_from_word(file_stream)
            try:
                word_images = self.extract_images_from_word(file_stream)
            except:
                word_images = []
            return [word_text, word_images]
        elif file_extension in ["jpg", "jpeg", "png"]:
            images = self.extract_picture(file_stream)
            return ["", images]

    @staticmethod
    def calculate_token(username: str, file_names: list, model: str = "gpt-4o"):
        """
        计算文件列表的总 token 数量（文本 + 图片）

        Args:
            username: 用户名
            file_names: 文件名列表
            model: 模型名称，默认 "gpt-4o"，支持 "gpt-5.1" 等

        Returns:
            int: 总 token 数量
        """
        try:
            encoding = tiktoken.encoding_for_model(model)
        except:
            # GPT-5.1 和其他新模型使用 o200k_base 编码
            # GPT-4o, GPT-4 系列使用 cl100k_base 编码
            if "gpt-5" in model.lower() or "o1" in model.lower():
                encoding = tiktoken.get_encoding("o200k_base")
            else:
                encoding = tiktoken.get_encoding("cl100k_base")

        total_tokens = 0
        file_op = FileOperation()

        for file_name in file_names:
            try:
                text_content, images = file_op(username, file_name)

                # 计算文本 tokens
                if text_content:
                    text_tokens = len(encoding.encode(text_content))
                    total_tokens += text_tokens

                # 计算图片 tokens (每张图片约 85-765 tokens，取决于尺寸)
                # 这里使用简化估算：每张图片按 500 tokens 计算
                # 实际应根据图片尺寸计算，详见 OpenAI 文档
                if images:
                    image_tokens = len(images) * 500
                    total_tokens += image_tokens

            except Exception as e:
                print(f"处理文件 {file_name} 时出错: {str(e)}")
                continue

        return total_tokens

    @staticmethod
    def process_local_file(file_path: str):
        """
        本地文件处理（用于测试）

        Args:
            file_path: 本地文件路径

        Returns:
            [text_content, images]: 文本内容和图片列表
        """
        import os

        if not os.path.exists(file_path):
            raise FileNotFoundError(f"文件不存在: {file_path}")

        file_extension = file_path.rsplit(".", 1)[1].lower()

        with open(file_path, "rb") as f:
            stream = f.read()

        file_stream = io.BytesIO(stream)
        encoding = chardet.detect(stream)["encoding"]

        if file_extension == "txt":
            txt_content = stream.decode(encoding)
            return [txt_content, []]
        elif file_extension == "csv":
            df = pd.read_csv(file_stream, encoding=encoding)
            return [df.to_json(force_ascii=False), []]
        elif file_extension == "json":
            json_content = stream.decode(encoding)
            return [json_content, []]
        elif file_extension in ["xlsx", "xls"]:
            df = pd.read_excel(file_stream, engine="openpyxl")
            return [df.to_json(force_ascii=False), []]
        elif file_extension == "pdf":
            pdf_text, page_num = FileOperation.extract_text_from_pdf(stream)
            pdf_images = FileOperation.extract_images_from_pdf(
                stream, page_num)
            return [pdf_text, pdf_images]
        elif file_extension == "docx":
            word_text = FileOperation.extract_text_from_word(file_stream)
            try:
                word_images = FileOperation.extract_images_from_word(
                    file_stream)
            except:
                word_images = []
            return [word_text, word_images]
        elif file_extension in ["jpg", "jpeg", "png"]:
            images = FileOperation.extract_picture(file_stream)
            return ["", images]

        return ["", []]

    @staticmethod
    def calculate_token_local(file_paths: list, model: str = "gpt-4o"):
        """
        计算本地文件列表的总 token 数量（用于测试）

        Args:
            file_paths: 本地文件路径列表
            model: 模型名称，默认 "gpt-4o"，支持 "gpt-5.1" 等

        Returns:
            int: 总 token 数量
        """
        try:
            encoding = tiktoken.encoding_for_model(model)
        except:
            # GPT-5.1 和其他新模型使用 o200k_base 编码
            # GPT-4o, GPT-4 系列使用 cl100k_base 编码
            if "gpt-5" in model.lower() or "o1" in model.lower():
                encoding = tiktoken.get_encoding("o200k_base")
            else:
                encoding = tiktoken.get_encoding("cl100k_base")

        total_tokens = 0

        for file_path in file_paths:
            try:
                text_content, images = FileOperation.process_local_file(
                    file_path)

                # 计算文本 tokens
                if text_content:
                    text_tokens = len(encoding.encode(text_content))
                    total_tokens += text_tokens
                    print(f"文件 {file_path} - 文本 tokens: {text_tokens}")

                # 计算图片 tokens
                if images:
                    image_tokens = len(images) * 500
                    total_tokens += image_tokens
                    print(
                        f"文件 {file_path} - 图片数量: {len(images)}, 图片 tokens: {image_tokens}")

            except Exception as e:
                print(f"处理文件 {file_path} 时出错: {str(e)}")
                continue

        return total_tokens


    # 本地测试示例
    attachments = [
        "Dify安装和部署简要入门.pdf",
        "Transformer.pdf"
    ]
    print("=" * 50)
    print("文件处理测试:")
    print("=" * 50)
    
        for file_path in attachments:
        print(f"\n处理文件: {file_path}")
        try:
            # 对于 .py 文件，直接读取文本内容
            import os
            if file_path.endswith('.py'):
                with open(file_path, 'r', encoding='utf-8') as f:
                    text = f.read()
                images = []
            else:
                text, images = FileOperation.process_local_file(file_path)
            
            print(f"  ✓ 文本长度: {len(text)} 字符")
            print(f"  ✓ 图片数量: {len(images)}")
            if text:
                print(f"  ✓ 文本预览: {text[:100]}...")
    except Exception as e:
            print(f"  ✗ 错误: {e}")

    # 测试 token 计算
    print("\n" + "=" * 50)
    print("计算总 Token 数量:")
    print("=" * 50)
    
    # 可以在这里修改模型名称
    model_name = "gpt-5.1"  # 支持: "gpt-4o", "gpt-5.1", "o1-preview" 等
    print(f"使用模型: {model_name}")
    
    try:
        # 对于 .py 文件，手动计算 token
        try:
            encoding = tiktoken.encoding_for_model(model_name)
        except:
            # GPT-5.1 和其他新模型使用 o200k_base 编码
            if "gpt-5" in model_name.lower() or "o1" in model_name.lower():
                encoding = tiktoken.get_encoding("o200k_base")
            else:
                encoding = tiktoken.get_encoding("cl100k_base")
        
        total_tokens = 0
        for file_path in attachments:
            if file_path.endswith('.py'):
                with open(file_path, 'r', encoding='utf-8') as f:
                    text = f.read()
                tokens = len(encoding.encode(text))
                total_tokens += tokens
                print(f"  - {file_path}: {tokens} tokens")
            else:
                text, images = FileOperation.process_local_file(file_path)
                text_tokens = len(encoding.encode(text)) if text else 0
                image_tokens = len(images) * 500 if images else 0
                total_tokens += text_tokens + image_tokens
                print(f"  - {file_path}: {text_tokens} tokens (文本) + {image_tokens} tokens (图片)")
        
        print(f"\n总计: {total_tokens} tokens (模型: {model_name})")
    except Exception as e:
        print(f"错误: {e}")
