# Token计算API文档

## 概述
新增的 `/calculate_token` API 用于计算文件列表消耗的token数量，支持文本和图片的综合计算。

## API端点
```
POST /dev-api/calculate_token
```

## 请求参数

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| username | string | 是 | 用户名 |
| filenames | array[string] | 是 | 文件名列表（可传入多个） |
| model | string | 否 | 模型名称，默认为 `gpt-4o` |

### 支持的模型
- `gpt-4.1`
- `gpt-4o` (默认)
- `gpt-5.1`

## 请求示例

### JSON格式
```json
{
  "username": "testuser",
  "filenames": ["document.pdf", "report.docx"],
  "model": "gpt-4o"
}
```

### cURL示例
```bash
curl -X POST http://localhost:5000/dev-api/calculate_token \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "filenames": ["document.pdf", "report.docx"],
    "model": "gpt-4o"
  }'
```

## 响应格式

### 成功响应 (200)
```json
{
  "data": {
    "total_tokens": 15420,
    "model": "gpt-4o",
    "encoding": "o200k_base",
    "file_count": 2,
    "files": [
      {
        "filename": "document.pdf",
        "text_tokens": 8500,
        "image_tokens": 510,
        "total_tokens": 9010,
        "image_count": 3
      },
      {
        "filename": "report.docx",
        "text_tokens": 6410,
        "image_tokens": 0,
        "total_tokens": 6410,
        "image_count": 0
      }
    ]
  },
  "code": 200
}
```

### 错误响应

#### 无效模型 (400)
```json
{
  "msg": "无效的模型名称。支持的模型: gpt-4.1, gpt-4o, gpt-5.1",
  "code": 400
}
```

#### 用户不存在 (404)
```json
{
  "msg": "用户名不存在",
  "code": 404
}
```

#### 计算失败 (500)
```json
{
  "msg": "Token计算失败: [错误详情]",
  "code": 500
}
```

## 功能说明

### Token计算规则

1. **文本Token计算**
   - 使用 tiktoken 库根据模型编码方式计算
   - 支持PDF、Word、Excel、TXT、JSON等文本内容

2. **图片Token计算**
   - 基于OpenAI的图片token计算规则
   - 高分辨率图片: 170 tokens + (tiles × 170)
   - 低分辨率图片: 85 tokens
   - 根据图片尺寸自动计算tile数量

3. **综合计算**
   - 返回每个文件的文本token、图片token和总token
   - 汇总所有文件的总token数

## 安装依赖

确保已安装 `tiktoken` 库：
```bash
pip install tiktoken==0.8.0
```

或使用项目的 requirements.txt：
```bash
pip install -r requirements.txt
```

## 注意事项

1. 文件必须已上传到用户的存储空间
2. 支持的文件格式：pdf, xlsx, txt, xls, json, docx, jpg, jpeg, png
3. 图片token计算为估算值，实际消耗可能略有差异
4. 大文件可能需要较长处理时间

## 前端集成说明

### 文件上传流程（带Token验证）

前端在上传文件时会自动进行Token验证：

1. **文件格式验证** - 检查文件扩展名是否在允许列表中
2. **文件大小验证** - 检查总文件大小是否超过5MB
3. **临时上传** - 将文件上传到服务器
4. **Token计算** - 调用 `/calculate_token` API计算所有文件的总Token数
5. **Token限制检查** - 如果总Token数超过100,000：
   - 立即删除刚上传的文件
   - 显示错误消息："アップロードされたドキュメントが複雑すぎます。再度アップロードしてください。"
   - 阻止文件添加到附件列表
6. **成功确认** - 如果Token数在限制内，将文件添加到附件列表并显示成功消息

### Token限制

- **最大Token数**: 100,000
- **超过限制时的行为**: 自动删除文件并提示用户重新上传更简单的文档

## 前端集成说明

### 文件上传流程（带Token验证）

前端在上传文件时会自动进行Token数量验证：

1. **文件格式验证** - 检查文件扩展名是否在允许列表中
2. **文件大小验证** - 检查总文件大小是否超过5MB
3. **上传文件** - 将文件上传到服务器
4. **Token计算** - 调用 `/calculate_token` API 计算所有文件的总Token数
5. **Token限制检查** - 如果总Token数超过100,000：
   - 自动删除刚上传的文件
   - 显示错误提示：「アップロードされたドキュメントが複雑すぎます。再度アップロードしてください。」
   - 阻止文件添加到附件列表
6. **成功添加** - Token数在限制内，文件添加到附件列表

### Token限制

- **最大Token数**: 100,000 tokens
- **超过限制**: 自动拒绝上传并删除文件
- **错误提示**: 日文提示用户文档过于复杂

### 实现细节

```javascri
